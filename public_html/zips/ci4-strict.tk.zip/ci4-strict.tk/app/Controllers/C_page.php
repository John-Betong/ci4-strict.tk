<?php DECLARE(STRICT_TYPES=1);  

namespace App\Controllers;

//=========================================  
class C_page extends BaseController
{

//=========================================  
public function index($page='7') // 'welcome_message')
{
  $pages = [
    'info', 
    'source-files', 
    'conversion-script',
    'bugs-app',
    'bugs-public',
    'bugs-system',
    'download-install',
    'strict-0',
    'strict-1',
    'strict-not',
    'myths',
    'rsync',
  ];
  $data['title']      = 'Ci4-Strict.tk'; //
  $data['style_tla']  = $this->style_tla;

  if( (int) $page && (int) $page <= 10) :
    $page   = str_pad($page, 3, "0", STR_PAD_LEFT); 
    $page   = 'vPage-' .$page;

  elseif( in_array($page, $pages) ) :  
    $page = 'v-' .$page;

  else :  
    $data['title'] = 'welcome_message';
    // WHOOPS
    # $page =  'welcome_message'; 
    # $page = 'v-strict-0';
  endif;

  $data['vPage']  =  $page; 

	return view($data['vPage'], $data);
}//


}///
