<?php DECLARE(STRICT_TYPES=1);  namespace Config;

class ForeignCharacters extends \CodeIgniter\Config\ForeignCharacters
{

}
