<?php DECLARE(STRICT_TYPES=1);  namespace CodeIgniter\Exceptions;

/**
 * Error: Critical conditions, like component unavailble, etc.
 */

class CriticalError extends \Error
{

}
