<?php DECLARE(STRICT_TYPES=1); 

namespace Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
