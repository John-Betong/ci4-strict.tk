<?php DECLARE(STRICT_TYPES=1);

# DEBUG MODIFICATIONNS START =========================================
  require '/var/www/ci2/fred.php';
 
  define('LOCALHOST', 'localhost'===$_SERVER['SERVER_NAME']);
  define('CI_DEBUG',  FALSE) ; // LOCALHOST); 

# MAYBE EMPTY TRASH
  $ok = @unlink('../writable/logs/log-' .date('Y-m-d') .'.php');
  $ok = @array_map('unlink', glob("../writable/debugbar/*.json"));

  $tmpUrl = 'https://ci4-strict.tk/';
  if(LOCALHOST):
    $tmpUrl = 'http://localhost/ci4-strict.tk/public_html/';
  endif;
  define('BASEURL',  $tmpUrl);

  $tmpEnv = 'production'; // 'development'
  if(CI_DEBUG) : 
    $tmpEnv = 'development'; // 'production'  
  endif;  
  define('CI_ENVIRONMENT',   $tmpEnv);
  $_SERVER['CI_ENVIRONMENT'] = $tmpEnv;
// DEBUG MODIFICATIONNS END ===========================================
