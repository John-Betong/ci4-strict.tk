<?php DECLARE(STRICT_TYPES=1);

require ROOTPATH .'Views/incs/doctype-001.php'; 


# REQUIRE test function
# DEFAULT
  $strict = 'v-strict-0'===$vPage ? '0' : '1';

  $fff = ROOTPATH .'Views/strict-tests/strict_func_types_on.php';
  if('v-strict-not'===$vPage) :
    $fff = ROOTPATH .'Views/strict-tests/strict_func_types_off.php';
  endif;  
  require $fff;
  $fnStrict = highlight_file($fff, TRUE);

  $st01 = BASEURL .'strict-0';
  $st02 = BASEURL .'strict-1';
  $st03 = BASEURL .'strict-not';

?>
<body>
  <div class="header tac">
    <?php require ROOTPATH .'Views/incs/logo-001.php'; ?>
    <!-- h4 class="hhh ooo"> Strict_types=0 </h4 -->  
  </div>

  <div class="nav">
    <?php require ROOTPATH .'Views/incs/menu-001.php' ?>
  </div>
 
  <div class="article">
    <h2 class="ooo"> Declare Strict - Myths and Clarification </h2>
    <p> &nbsp; </p>

    <dl>
      <dt> TL;DR;  </dt>
      <dd> 
          <blockquote>
            Instead study the three examples on the left menu which declare strict_types and include a PHP with with functions:
            <ol>
              <li> <a href="<?= $st01 ?>"> strict_types=0; </a> </li>
              <li> <a href="<?= $st02 ?>"> strict_types=1; </a> </li>
              <li> <a href="<?= $st03 ?>"> strict_types=0 - ignore; </a> </li>
            </ol>
          </blockquote>

      </dd>
      <dd> &nbsp; </dd>


      <dt> PHP - Brief History  </dt>
      <dd> 
        <p>
        Introduced nearly 25 years ago! Originally designed to simply enhance web development. The simplistic approach necessitated a large amount of script to 
        ensure make writing HTML script was very easy. 
        </p>
        <p>
        Unfortunately making PHP more user friendly increased processing time and PHP aquired a reputation for being very slow...
        </p>
      </dd>
      <dd> &nbsp; </dd>



      <dt> PHP 7 has overcome slow processing... </dt>
      <dd> 
        <p>
          Released December 2015,
          it not only but also achieved better performance but also does not affect legacy code! 
        </p>

        <p>
          Most performance is due to eliminating "Type juggling". 
        </p>

        <blockquote class="w88 mga fwb">
          Native PHP functions now have all function parameters types and return types set!
        </blockquote>

        <p>    
          This feature would have made all legacy libraries fail but has been cunningly implemented and applies **ONLY** if the following declaration is the first file statement.
        </p>

        <blockquote class="w88 mga fwb">
          &lt;?php declare(strict_types=1);
        </blockquote>
        
        <p>
          The strict validation checks <b>only</b> apply to the file where the declaration has been set!
        </p>

        <p>
           This new feature is vastly misunderstood and can be simplified with the following three usage types which cover every eventuality:
        </p>
        <ol>
          <li> Do not use the feature - ideal for **OLD** external libraries. </li>
          <li> 
            Declare strict_types - usage: 
            <ol>
              <li> 
                Native PHP function parameter types must match otherwise errors will be activated.
              </li>
              <li> 
                Included files having functions have two options 
              </li>
              <li> 
                asdf
              </li>
              <li> 
                asdf
              </li>
            </ol>
          </li>
          <li> &nbsp; </li>
        </ol>
      </dd>
      
      <dd> &nbsp; </dd>
      <dd> &nbsp; </dd>
      <dd> &nbsp; </dd>

      <dt> asdf </dt>
      <dd> &nbsp; </dd>
      <dd> sadf </dd>
      <dd> &nbsp; </dd>
      <dd> &nbsp; </dd>
      <dd> &nbsp; </dd>

    </dl>
  </div><!-- article -->
  
  <div class="footer">
    <?php require '/var/www/footer.php'; ?>
  </div><!-- footer -->
  
</body>
</html>