<?php DECLARE(STRICT_TYPES=1);

?>
An uncaught Exception was encountered

Type:        <?= get_class($exception), "\n"; ?>
Message:     <?= $message, "\n"; ?>
Filename:    <?= $exception->getFile(), "\n"; ?>
Line Number: <?= $exception->getLine(); ?>

if(0):

<?php if (defined('SHOW_DEBUG_BACKTRACE') && SHOW_DEBUG_BACKTRACE === true): ?>

	Backtrace:
	<?php foreach ($exception->getTrace() as $error): ?>
		<?php if (isset($error['file'])): ?>
			<?= trim('-' . $error['line'] . ' - ' . $error['file'] . '::' . $error['function']) . "\n" ?>
		<?php endif ?>
	<?php endforeach ?>

<?php endif ?>

<?php 
else: 
  if (defined('SHOW_DEBUG_BACKTRACE') && SHOW_DEBUG_BACKTRACE === true): 

  echo 'XXX ==> Backtrace:';
  foreach ($exception->getTrace() as $error): 
    if (isset($error['file'])): 
      echo trim
      (
         '-' 
        . $error['line'] 
        . ' - ' 
        . $error['file'] 
        . '::' 
        . $error['function']) 
        . "\n"
        ;
    endif; 
  endforeach; 

<?php endif ?>
endif;  