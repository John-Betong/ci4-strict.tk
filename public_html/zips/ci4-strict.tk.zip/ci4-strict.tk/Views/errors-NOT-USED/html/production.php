<?php // DECLARE(STRICT_TYPES=1);


?><!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="robots" content="noindex">

	<title>Whoops!</title>

	<style type="text/css">
		<?= preg_replace('#[\r\n\t ]+#', ' ', file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . 'debug.css')) ?>
		.whoops {
			background-color: #ddffff; color: #000;
			border: solid 1px #888;
			font-size: small;
			margin:0 auto; padding: 0.42em;
			width:88%; max-width:88em;
		}
		.ooo {margin: 0 0 2em 0; padding: 0;}
	</style>
</head>
<body>

	<div class="container text-center">
		<h1 class="XXXheadline"> Whoops! </h1>

		<p class="lead">We seem to have hit a snag. Please try again later...</p>
	</div>

	<?php 
		# better if LOCALHOST defined in 'index.php'
		if( 'localhost'===$_SERVER['SERVER_NAME'] ) :
			$today = 'logs/log-' .date('Y-m-d') .'.php';
			$today = highlight_file(WRITEPATH .$today, TRUE);

			echo '<div class="whoops">'
						.	'<dl>'
						.	'<dt><b> The last error which must be fixed </b></dt>'
  					.		'<dd><br>' .$today .'</dd>'
						.'</dl>'
					. '</div>'
					;	
	endif;
	?>	
	</div>	

</body>

</html>
