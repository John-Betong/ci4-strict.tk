<?php DECLARE(STRICT_TYPES=1);

require ROOTPATH .'Views/incs/doctype-001.php'; 

# DEFAULT
  $strict = 'v-strict-0'===$vPage ? '0' : '1';

  $fff = ROOTPATH .'Views/strict-tests/strict_func_types_on.php';
  if('v-strict-not'===$vPage) :
    $fff = ROOTPATH .'Views/strict-tests/strict_func_types_off.php';
  endif;  
  require $fff;
  $fnStrict = highlight_file($fff, TRUE);


?><body>

  <div class="header tac">
    <?php require ROOTPATH .'Views/incs/logo-001.php'; ?>
    <h4 class="hhh ooo"> Strict_types=0 </h4>  
  </div><!-- header -->

  <div class="nav">
    <?php require ROOTPATH .'Views/incs/menu-001.php' ?>
  </div>

  <div class="article">
    <?php
      echo '<dl class="ooo">';
        echo '<dt> This file: Strict_types=' .$strict .'</dt>';
        echo '<dd class="w88 mga tal bgs p42">';
        try {
          echo '<div> &nbsp; </div>';
          echo '<h4 class="ooo"> Test #1: passing two <b>integer</b> parameters: </h4>';
          echo '<div class="w88 mga"> echo sumTwoIntegers (2, 4) = ' 
               . sumTwoIntegers (2, 4)
               .'</div>';
        } catch (Exception $e) {
          echo '<b> Caught exception: ',  $e->getMessage(), "</b>\n";
        }

        try {
          echo '<div> &nbsp; </div>';
          echo '<h4 class="ooo"> Test #2: passing two <b>float</b> parameters: </h4>';
          echo '<div class="w88 mga "> echo sumTwoIntegers (2.22, 4.22) = ' 
               . sumTwoIntegers(2.22, 4.44)
               .'</div>';
        } catch (Exception $e) {
          echo '<b> Caught exception: ',  $e->getMessage(), "</b>\n";
        }

        try {
          echo '<div> &nbsp; </div>';
          echo '<h4 class="ooo"> Test #3: passing two <b>string</b> parameters: </h4>';
          echo '<div class="w88 mga"> echo sumTwoIntegers ("2.22", "4.22") = ' 
               . sumTwoIntegers ("2.22", $y="4.22")
               .'</div>';

        } catch (Exception $e) {
          echo '<b> Caught exception: ',  $e->getMessage(), "</b>\n";
        }
        echo '<br>';

        echo '</dd>';
        echo '<dd> &nbsp; </dd><dd> &nbsp; </dd>';
        echo '<dt> Calling following included function </dt>';
        echo '<dd> &nbsp; </dd>';
             echo '<dd class="bd1 bgc dib" style="border:solid 1px #888;">'
               .$fnStrict 
                .'</dd>';

      echo '</dl>';
    ?>      
  </div><!-- article -->
  
  <div class="footer">
    <?php include '/var/www/footer.php'; ?>
  </div><!-- footer -->
  
</body>
</html>