<?php DECLARE(STRICT_TYPES=1);

require ROOTPATH .'Views/incs/doctype-001.php'; 

?>

<body>

  <div class="header tac">
    <?php require ROOTPATH .'Views/incs/logo-001.php'; ?>
    <h4 class="hhh ooo"> Strict_types=0 </h4>  
  </div><!-- header -->

  <div class="nav">
    <?php require ROOTPATH .'Views/incs/menu-001.php' ?>
  </div>

  <div class="article">
    <h2 class="ooo"> Source file used to insert DECLARE(STRICT_TYPES=1); </h2>
    <p class="ooo"> &nbsp; </p>
  
    <i class="fsl">file: </i> <b> STRICT_INSERT.php </b>
    <br><br>
    <div class="w99 mga p42 bgs bd1">
      <?php highlight_file('../STRICT-INSERT.php'); ?>
    </div>
  </div><!-- article -->
  
  <div class="footer">
    <?php include '/var/www/footer.php'; ?>
  </div>

</body>
</html>