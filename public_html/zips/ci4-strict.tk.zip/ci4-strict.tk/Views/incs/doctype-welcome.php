<?php DECLARE(STRICT_TYPES=1);

$title = 'CodeIgniter4 welcomes you to a warm and STRICT debugging experience';

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> <?= $title ?>  </title>
<style>
  <?= file_get_contents(ROOTPATH . 'Views/incs/style-ci4.min.css'); ?>
  <?= file_get_contents(ROOTPATH . 'Views/incs/style-tla.min.css'); ?>
</style>
</head>