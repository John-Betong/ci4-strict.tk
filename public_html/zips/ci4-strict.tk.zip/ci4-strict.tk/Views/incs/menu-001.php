<?php DECLARE(STRICT_TYPES=1);

# $strictOff  = BASEURL .'strict-types-test/index-types=0.php';
# $strictOn   = BASEURL .'strict-types-test/index-types=1.php';
$tmp   = 'strict-types-test/';
$items = [
  ['info'               , 'Information'], 
  ['source-files'       , 'Source files'], 
  ['conversion-script'  , 'Convert Script'], 
  ['bugs-app'           , '/app'], 
  ['bugs-public'        , '/public'], 
  ['bugs-system'        , '/system'], 
  ['download-install'   , 'Download &amp; Install'], 
  ['myths'              , 'Myths explained'], 
  ['strict-0'           , 'strict_types=0'], 
  ['strict-1'           , 'strict_types=1'], 
  ['strict-not'         , 'strict_NOT-SET'], 
  ['welcome-message'    , 'Welcome Message'], 
];

# ENHANCE SELECTION 
  $url = $url = $_SERVER['REQUEST_URI'];
  $url = strrchr($url, '/');
  $url = substr($url, 1);
  foreach($items as $id => $val):
    if( $url === $items[$id][0] ) :
      $items[$id][1] = '<b class="fgg">' 
        .   strtoupper($items[$id][1]) 
        .'&nbsp;&nbsp;&nbsp;  ==></b>';
    endif;  
  endforeach;

?>
  <dl class="menu-001 fss">
    <dt> Declare Strict MYTHS: </dt> 
    <dd><a class="fg0 fwb " href="<?=BASEURL.$items[7][0] ?>"> <?= $items[7][1] ?> </a></dd>
    <dd><a href="<?=BASEURL.$items[8][0] ?>"> <?= $items[8][1] ?> </a></dd>
    <dd><a href="<?=BASEURL.$items[9][0] ?>"> <?= $items[9][1] ?> </a></dd>
    <dd><a href="<?=BASEURL.$items[10][0]?>"> <?= $items[10][1] ?> </a></dd>

    <dt>Menu </dt>
    <dd><a href="<?= BASEURL .$items[0][0] ?>"> <?= $items[0][1] ?> </a></dd>
    <dd><a href="<?= BASEURL .$items[1][0] ?>"> <?= $items[1][1] ?> </a></dd>
    <dd><a href="<?= BASEURL .$items[2][0] ?>"> <?= $items[2][1] ?> </a></dd>
    <dd> &nbsp; </dd>

    <dt> Download & install  </dt>
    <dd> <a href="<?= BASEURL .$items[6][0]?>"> <?= $items[6][0] ?> </a> </dd>
    <dd> &nbsp; </dd>
    
    <dt> <a href="<?= BASEURL ?>"> welcome_message   </a> </dt>
    <dd> &nbsp; </dd>
  </dl>

<?php 
  if(LOCALHOST) :
    echo '<h2> <a class="fsl fgr" href="rsync">RSync</a> </h2>';
  endif;  
