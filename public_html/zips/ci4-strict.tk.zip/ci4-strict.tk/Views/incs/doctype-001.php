<?php DECLARE(STRICT_TYPES=1);

?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<title> <?= $title ?>  </title>
<style>
  <?= $style_tla ?> 
</style>
</head>

<?php 
/*
article {
  background-image: url(https://ci4-strict.tk/assets/svg/logo.svg);
}  

article{
    position: relative;
    z-index:1;
    overflow:hidden; 
}
article:before{
    z-index:-1;
    position:absolute;
    left:0;
    top:0;
    content: url(https://ci4-strict.tk/assets/svg/logo.svg);
    opacity:0.4;
}

XXXarticle:hover:before{
    opacity:1;
}
*/