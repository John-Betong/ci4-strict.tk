<?php  DECLARE(STRICT_TYPES=1);

header('Location: index-strict_types=0.php');
