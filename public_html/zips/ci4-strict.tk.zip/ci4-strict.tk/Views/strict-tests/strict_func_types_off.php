<?php declare(STRICT_TYPES=1); # strict_func_types_off.php

$INFO = <<< ____EOT
/*
  Points to note:
  1. strict_types=1 and has no effect
  2. NO typed parameters
  3. NO return type
*/
____EOT;

//==============================
function sumTwoIntegers ($x, $y)
{
  $result = $x + $y;

  return $result;
}


//==============================
function productTwoIntegers ($x, $y)
{
  $result = $x * $y;

  return $result;
}

 //==============================
 function void ()
  :void
  {
    # return $x * $y;
  }//
