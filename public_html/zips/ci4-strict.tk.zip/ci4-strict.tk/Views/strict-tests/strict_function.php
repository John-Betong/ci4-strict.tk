<?php declare(STRICT_TYPES=1);

if('v-strict-not'===$vPage) :
 //==============================
 function sumTwoIntegers ($x, $y)
  # :int
  {
    $result = $x + $y;

    # return (integer) $result + 1000  ;
    return $result;
  }//

 //==============================
 function productTwoIntegers ($x, $y)
  # :int
  {
    $result = $x * $y;

    # return (integer) $result + 1000  ;
    return $result;
  }//
else:  
 //==============================
 function sumTwoIntegers ( int $x, int $y )
  :int
  {
    return $x + $y;
  }//

 //==============================
 function productTwoIntegers ( int $x, int $y )
  :int
  {
    return $x * $y;
  }//
endif;  

 //==============================
 function void ()
  :void
  {
    # return $x * $y;
  }//
