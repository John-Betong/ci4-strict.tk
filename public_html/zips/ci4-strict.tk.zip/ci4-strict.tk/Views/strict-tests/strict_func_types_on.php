<?php declare(STRICT_TYPES=1); # strict_func_types_on.php

$INFO = <<< ____EOT
/*
  Points to note:
  1. strict_types=1
  2. parameters have types
  3. return type is set
*/
____EOT;

//==============================
function sumTwoIntegers ( int $x, int $y )
: int
{
  return $x + $y;
}

//==============================
function productTwoIntgers( int $x, int $y )
: int
{
  return $x * $y;
}

 //==============================
 function void ()
  :void
  {
    # return $x * $y;
  }//
