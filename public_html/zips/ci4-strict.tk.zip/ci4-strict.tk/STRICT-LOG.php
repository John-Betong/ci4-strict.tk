Source:
sudo git clone https://github.com/codeigniter4/CodeIgniter4.git

# Notes:
  Multiple &lt?php statements so a MANUAL REPLACE REQUIRED  

MANUAL REPLACE REQUIRED: 6 ==> app/Views/errors/cli/error_exception.php
MANUAL REPLACE REQUIRED: 3 ==> app/Views/errors/html/error_404.php
MANUAL REPLACE REQUIRED: 69 ==> app/Views/errors/html/error_exception.php


MANUAL REPLACE REQUIRED: 2 ==> system/Autoloader/Autoloader.php
MANUAL REPLACE REQUIRED: 2 ==> system/Helpers/text_helper.php
MANUAL REPLACE REQUIRED: 2 ==> system/Typography/Typography.php
MANUAL REPLACE REQUIRED: 7 ==> system/View/Parser.php
MANUAL REPLACE REQUIRED: 2 ==> system/Commands/Database/CreateMigration.php
MANUAL REPLACE REQUIRED: 2 ==> system/Commands/Sessions/CreateMigration.php
MANUAL REPLACE REQUIRED: 2 ==> system/Log/Handlers/FileHandler.php
MANUAL REPLACE REQUIRED: 7 ==> system/Pager/Views/default_full.php
MANUAL REPLACE REQUIRED: 4 ==> system/Validation/Views/list.php
MANUAL REPLACE REQUIRED: 5 ==> system/Commands/Sessions/Views/migration.tpl.php
MANUAL REPLACE REQUIRED: 54 ==> system/Debug/Toolbar/Views/toolbar.tpl.php
MANUAL REPLACE REQUIRED: 2 ==> system/Debug/Toolbar/Views/toolbarloader.js.php