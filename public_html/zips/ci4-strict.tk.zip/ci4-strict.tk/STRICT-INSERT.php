<?php DECLARE(STRICT_TYPES=1);

define('ONCE_ONLY', 1);

echo '<h2> Source: <h2>';
echo '<h4> sudo git clone https://github.com/codeigniter4/CodeIgniter4.git </h4>';

//========================================================
  $path = ['app', 'public', 'system', 'writable'] ; 
  foreach($path as $id => $path) :

    echo '<pre>';
      $aff = scandir_through($dir=$path) ;

      # print_r( $aff = scandir_through($dir='app') );
      foreach($aff as $id => $ff) :
        if( is_dir($ff) ):
          // DO NOTHING
        else:
          fnAddStrictTypes($ff);
        endif;
      endforeach;    
    echo '</pre>';

  endforeach;    

//========================================================
function scandir_through($dir)
{
  $items = glob($dir . '/*');

  for ($i = 0; $i < count($items); $i++) {
      if (is_dir($items[$i])) {
          $add   = glob($items[$i] . '/*');
          $items = array_merge($items, $add);
      }
  }

  return $items;
}

//========================================================
function fnAddStrictTypes($fff)
{
  # echo $fff;
  #var_dump($fff);
  if( strpos($fff, '.php') ) :
    # exit;
    $ff = file_get_contents($fff) ;


    if( strpos( $ff, 'DECLARE(STRICT_TYPES=1') ) :
      echo '<br> ALREADY REPLACED: ==> ' .$fff;
    else:
      $cntByRef = 0;
      $ff = str_replace
        (
          '<?php', '<?php DECLARE(STRICT_TYPES=1); ', $ff, $cntByRef
        );  // ONCE_ONLY
      if($cntByRef > 1) :
        echo '<br> <b> MANUAL REPLACE REQUIRED: </b>' 
            . $cntByRef 
            . ' ==> '
            . $fff
            ;
      else:  
        $ok = file_put_contents($fff, $ff) ;
        # echo '<br> Replaced: ' .$fff; 
      endif;  
    endif;  

  else:
    # echo '<p> Nope: '.$fff .'</p>';
  endif;  
}//


//====== DEBUG ===========================================
function fred($val='', $title=NULL)
{
  $style = 'width:88%; margin:2em auto; 
            background-color: snow; color: #000; 
            padding: 0.42em; border: solid 1px #888;';
  if($title):
    echo $title . ' ==> ';
  else:  
    echo '';
  endif;  

  echo "<pre style='$style'> <b>Debug ==>  </b>";
    echo $title;
      print_r($val);
  echo '</pre>';
}//
 