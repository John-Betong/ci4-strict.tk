<?php DECLARE(STRICT_TYPES=1);  namespace CodeIgniter\Exceptions;

/**
 * Error: system is unusable
 */

class EmergencyError extends \Error
{

}
