<?php DECLARE(STRICT_TYPES=1); 
/**
 * Files language strings.
 *
 * @package    CodeIgniter
 * @author     CodeIgniter Dev Team
 * @copyright  2014-2019 British Columbia Institute of Technology (https://bcit.ca/)
 * @license    https://opensource.org/licenses/MIT	MIT License
 * @link       https://codeigniter.com
 * @since      Version 4.0.0
 * @filesource
 *
 * @codeCoverageIgnore
 */

return [
   'fileNotFound' => 'File not found: {0}',
   'cannotMove'   => 'Could not move file {0} to {1} ({2})',
];
