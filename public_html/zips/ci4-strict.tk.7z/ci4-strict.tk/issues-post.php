<?php 

> `I don't see a problem statement??
It sounds like you have made a workaround for CI4 not having strict typing??
You have raised this issue before - several threads, in CI4 feature requests, CI4 discussion and CI4 support.
How is not having strict typing a problem?

There was a PR submitted(https://github.com/codeigniter4/CodeIgniter4/pull/1493), which was not accepted because there are a number of places where we want flexible typing.
//=================================================

> I don't see a problem statement??
There are two logs files showing three CRITICAL errors.


> It sounds like you have made a workaround for CI4 not having strict typing??
I changed the incorrect function parameter types in accordance with the PHP manual's specifications.


> You have raised this issue before - several threads, in CI4 feature requests, CI4 discussion and CI4 support.
I have just checked the latest CI4 source files and the functions parameters have not been rectified? How can I request these errors to be modified because every time a new version is released it is necessary to manually make the changes.


> How is not having strict typing a problem?
When not having strict typing it is possible that the function parameter type is incorrect and PHP type juggling will not guess the desired value.


> There was a PR submitted(https://github.com/codeigniter4/CodeIgniter4/pull/1493), which was not accepted because there are a number of places where we want flexible typing.
I will reply later because I have guests arriving very shortly.

//== Jim Parry ======================================================================
  Those CRITICAL errors only show with strict typing, right?
  And CI4 does not use strict typing.
  You have posted this in the CI4 support forum, suggesting there is a problem with the framework, but it is instead with your changes to it, isn't it?
  That doesn't make these an error in the framework, but rather a feature request on your part, which not everyone agrees with.
//== Jim Parry ======================================================================
OK, point taken and accept that CI4 does not use strict_types.

The first CRITERIA is that an integer parameter is passed and the PHP function is expecting a string.

Is it acceptable to request changes that conform to the PHP Standards?


//=== Lonnie Ezell ===================================================================
  I don't know that it's a more elegant answer, but here goes:

  Like it or not, at its core, PHP is a flexibly typed language. It is not a typed language like Java or Hack, and that should be embraced. While I understand why people like the idea of it, and why it's helpful, I don't think it's appropriate for CodeIgniter. Type casting is actually a handy thing at times, and the other newer features that came with strict typing, like more argument and return value type hints go a long way toward fixing the issues PHP had by failing loudly for the developer to see. But forcing them to manually cast every number retrieved from an HTML form into an integer, and the like, is an unnecessary burden, I feel.

  In short (too late!) embrace PHP for what it is, and don't try to force it to be a language that it isn't.

  Thanks for the submittal, and for all of the other stuff you've helped out with, but I think we'll pass on this one.
//=== Lonnie Ezell ===================================================================
