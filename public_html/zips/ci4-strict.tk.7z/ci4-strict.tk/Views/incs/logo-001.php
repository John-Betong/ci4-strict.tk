<?php DECLARE(STRICT_TYPES=1);

defined('CI_DEBUG') ?: define('CI_DEBUG', FALSE);

$sup = CI_DEBUG ? 'True' 
                : ''
                ;

$sup  = '<sup class="fss fgr">' 
      .   $sup . ' ' 
      .   CodeIgniter\CodeIgniter::CI_VERSION 
      . '</sup>'
      ;                

?>
    
  <div class="fll logo"> 
    <a href="<?= BASEURL ?>" title="version <?= CodeIgniter\CodeIgniter::CI_VERSION ?>">
      <span class="fll">
        <?= file_get_contents('assets/svg/logo.svg'); ?>
      </span>
    </a>  
  </div>  

  <h1 class="tac dib fgg"> 
    CI4-Strict.tk
    <?= $sup ?>
  </h1>
