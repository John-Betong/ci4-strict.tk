<?php DECLARE(STRICT_TYPES=1);

require ROOTPATH .'Views/incs/doctype-001.php'; 

?>

<body> 

  <div class="header tac">
    <?php require ROOTPATH .'Views/incs/logo-001.php'; ?>
    <h4 class="hhh ooo"> Strict_types=0 </h4>  
  </div><!-- header -->

  <div class="nav">
    <?php require ROOTPATH .'Views/incs/menu-001.php' ?>
  </div>

  <div class="article">
    <h2 class="ooo">Source files: </h2>
    <p class="ooo"> &nbsp; </p>

    <dl>
      <dt> Special notes: </dt>
      <dd>
        <ol> 
          <li> Gitub <a href="#">source files</a> </li>
          <li> 
            <code>
              DECLARE(STRICT_TYPES=1);
            </code>
            inserted into:
            <ul>
              <li> every PHP file with a single PHP occurrence </li>
              <li> PHP with multiple references requires manually insertion </li>
            </ul>
           </li>
          <li> &nbsp; </li>
        </ol>
      </dd>
    </dl>
    <p class="ooo"> &nbsp; </p>

    <dl>
      <dt> Path: app  </dt>
      <dd>  
<pre> <?php # trim($tmpApp); ?> 
NOT REPLACED: 6 ==> app/Views/errors/cli/error_exception.php
NOT REPLACED: 3 ==> app/Views/errors/html/error_404.php
NOT REPLACED: 69 ==> app/Views/errors/html/error_exception.php


NOT REPLACED: 2 ==> system/Autoloader/Autoloader.php
NOT REPLACED: 2 ==> system/Helpers/text_helper.php
NOT REPLACED: 2 ==> system/Typography/Typography.php
NOT REPLACED: 7 ==> system/View/Parser.php
NOT REPLACED: 2 ==> system/Commands/Database/CreateMigration.php
NOT REPLACED: 2 ==> system/Commands/Sessions/CreateMigration.php
NOT REPLACED: 2 ==> system/Log/Handlers/FileHandler.php
NOT REPLACED: 7 ==> system/Pager/Views/default_full.php
NOT REPLACED: 4 ==> system/Validation/Views/list.php
NOT REPLACED: 5 ==> system/Commands/Sessions/Views/migration.tpl.php
NOT REPLACED: 54 ==> system/Debug/Toolbar/Views/toolbar.tpl.php
NOT REPLACED: 2 ==> system/Debug/Toolbar/Views/toolbarloader.js.php</pre>  
        </dd>
    </dl>
    <p> &nbsp; </p>

    <dl>
      <dt> Path: public - Inserted: public/index.php </dt>
      <dd> 
        <br>
        <?= highlight_file('index-DEBUG.php', TRUE) ?>
      </dd>
    </dl>
    <p class="ooo"> &nbsp; </p>

  </div><!-- article -->
  
  <div class="footer">
    <?php include '/var/www/footer.php'; ?>
  </div>

</body>
</html>