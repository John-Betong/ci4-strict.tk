<?php DECLARE(STRICT_TYPES=1);

require ROOTPATH .'Views/incs/doctype-001.php'; 

?>

<body>

  <div class="header tac">
    <?php require ROOTPATH .'Views/incs/logo-001.php'; ?>
    <h4 class="hhh ooo"> Strict_types=0 </h4>  
  </div><!-- header -->

  <div class="nav">
    <?php require ROOTPATH .'Views/incs/menu-001.php' ?>
  </div>

  <div class="article">
    <h2 class="ooo"> Source file used to insert DECLARE(STRICT_TYPES=1); </h2>
    <p class="ooo"> &nbsp; </p>
  
 <pre class="bgs dib"> 
# LOGIN

  ssh root@139.162.244.63
  
# APP
  rsync -avz  /var/www/ci4-strict.tk/app/  \
        -e    ssh \
        root@139.162.244.63:/var/www/ci4-strict.tk/app/

# VIEWS
  rsync -avz  /var/www/ci4-strict.tk/Views/ \
        -e    ssh \
        root@139.162.244.63:/var/www/ci4-strict.tk/Views/

# SYSTEM
  rsync -avz  /var/www/ci4-strict.tk/system/ \
        -e    ssh \
        root@139.162.244.63:/var/www/ci4-strict.tk/system/

# PUBLIC_HTML
  rsync -avz  /var/www/ci4-strict.tk/public_html/ \
        -e    ssh \
        root@139.162.244.63:/var/www/ci4-strict.tk/public_html/
</pre>

  </div><!-- article -->
  
  <div class="footer">
    <?php include '/var/www/footer.php'; ?>
  </div>

</body>
</html>

